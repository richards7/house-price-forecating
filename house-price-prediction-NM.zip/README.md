
# 🏠 Forecasting House Prices Using Smart Regression Techniques in Data Science

### 🔬 A Naan Mudhalvan Project | Powered by Google Colab

This project leverages **smart regression tools** such as **Random Forest** and **Support Vector Machines (SVM)** to accurately forecast house prices. Built entirely in **Google Colab**, this model pipeline applies end-to-end data science workflows — from cleaning data to deploying predictive models.

---

## 📌 Project Objective

To build an accurate and robust **house price prediction model** using smart machine learning techniques — specifically **Random Forest Regression** and **Support Vector Regression (SVR)** — by analyzing historical housing data.

---

## 🧪 Techniques Used

- 🔍 **Support Vector Regression (SVR)**
- 🌲 **Random Forest Regression**
- 🧠 Feature Scaling & Selection
- 📈 Exploratory Data Analysis
- 🔁 Cross-validation
- ✅ Performance Evaluation (RMSE, R² Score)

---

## 📊 Workflow

1. **Data Loading**  
   Load the dataset from a CSV file into a Colab environment.

2. **Data Cleaning & Preprocessing**  
   - Handle missing values  
   - Encode categorical features  
   - Normalize numerical columns

3. **Exploratory Data Analysis**  
   - Correlation heatmaps  
   - Price distribution  
   - Feature importance analysis

4. **Modeling**  
   - Train models using Random Forest and SVM  
   - Perform cross-validation  
   - Compare performance metrics

5. **Evaluation**  
   - RMSE  
   - MAE  
   - R² Score

6. **Output & Export**  
   - Save trained models  
   - Export predictions  
   - Generate PDF output from Google Colab

---

## 🧰 Tools & Libraries

- Python (NumPy, Pandas, Scikit-learn, Matplotlib, Seaborn)
- Google Colab
- RandomForestRegressor
- SVR (Support Vector Regression)
- Joblib (for model export)

---

## 📝 Sample Results

| Model                | RMSE   | R² Score |
|---------------------|--------|----------|
| Random Forest        | 20,400 | 0.90     |
| Support Vector Reg.  | 23,800 | 0.85     |

> 🎯 Random Forest showed the best performance and was selected as the final model.

---

## 📂 Files in This Repository

- `dataset.csv` – Cleaned dataset used for training  
- `source_code.py` – Python source code  
- `Output(Google Colab Implementation).pdf` – Notebook output as PDF  
- `README.md` – Project documentation (this file)

---

## 👨‍💻 Team Credits

Developed by:

- **Aashish Richard. J**
- **Abubakkar Siddique**
- **Mohamed Jafeer Jahirhussain**
- **Mohamed Zaid Basal Ahmed**

As part of the **Naan Mudhalvan** skill development initiative.

---

## 📌 Future Enhancements

- Deploy the model as a web app using Streamlit or Flask  
- Incorporate additional features like location clustering  
- Train deep learning models (e.g., ANN or CNN on images)

---

## 📎 Colab Access

> 👉 *This project is fully compatible with Google Colab.*

---

## 📩 Contact

For more details or academic references, feel free to reach out to any of the team members.

---
